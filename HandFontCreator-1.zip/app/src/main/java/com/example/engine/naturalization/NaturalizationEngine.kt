package com.example.engine.naturalization

import com.example.data.models.PencilHardness
import com.example.data.models.StylePreset
import kotlin.random.Random

data class NaturalizedCharTransform(
    val xOffset: Float,
    val yOffset: Float,
    val rotationDegrees: Float,
    val scaleFactor: Float,
    val alphaFactor: Float,
    val sampleIndex: Int
)

object NaturalizationEngine {

    /**
     * Calculates natural variations for a character based on the naturalization intensity (0.0 to 1.0) and preset.
     */
    fun calculateVariation(
        naturalness: Float,
        preset: StylePreset,
        charIndexInLine: Int,
        sampleCount: Int = 1,
        seed: Long = System.currentTimeMillis()
    ): NaturalizedCharTransform {
        val rand = Random(seed + charIndexInLine * 31L)

        // Effective intensity combines slider and preset baseline
        val intensity = (naturalness * 0.7f + preset.naturalness * 0.3f).coerceIn(0.0f, 1.0f)

        // Jitter ranges in dp
        val maxRot = 2.5f * intensity
        val rot = (rand.nextFloat() * 2f - 1f) * maxRot + preset.slant * 0.5f

        val maxYOffset = 3.5f * intensity
        // Slight baseline wobble that gently oscillates
        val yOffset = (rand.nextFloat() * 2f - 1f) * maxYOffset

        val maxXOffset = 1.5f * intensity
        val xOffset = (rand.nextFloat() * 2f - 1f) * maxXOffset

        // Scale variation (e.g. 96% to 104%)
        val scaleJitter = 0.08f * intensity
        val scale = 1.0f + (rand.nextFloat() * 2f - 1f) * scaleJitter

        // Ink density variation (subtle opacity changes)
        val alphaVariation = 0.12f * intensity
        val alpha = 1.0f - rand.nextFloat() * alphaVariation

        // Pick sample index if multiple samples exist
        val chosenSample = if (sampleCount > 1) {
            1 + rand.nextInt(sampleCount)
        } else {
            1
        }

        return NaturalizedCharTransform(
            xOffset = xOffset,
            yOffset = yOffset,
            rotationDegrees = rot,
            scaleFactor = scale,
            alphaFactor = alpha,
            sampleIndex = chosenSample
        )
    }

    /**
     * Resolves realistic pencil color with texture & hardness factors
     */
    fun resolvePencilColor(colorName: String, hardness: PencilHardness): Long {
        val baseColor = when (colorName.lowercase()) {
            "light gray" -> 0xFF888888L
            "medium gray" -> 0xFF555555L
            "dark gray" -> 0xFF333333L
            "graphite black" -> 0xFF181818L
            "pencil blue" -> 0xFF2B4C7EL
            "pencil red" -> 0xFF7E2B2BL
            "pencil green" -> 0xFF2B6E3AL
            else -> 0xFF2F3237L // Standard Graphite
        }
        return baseColor
    }

    fun resolvePenColor(colorName: String): Long {
        return when (colorName.lowercase()) {
            "black pen", "مشکی" -> 0xFF0A0A0AL
            "red pen", "قرمز" -> 0xFF881337L
            "green pen", "سبز" -> 0xFF064E3BL
            else -> 0xFF1E3A8AL // Classic Royal Blue Pen
        }
    }
}
