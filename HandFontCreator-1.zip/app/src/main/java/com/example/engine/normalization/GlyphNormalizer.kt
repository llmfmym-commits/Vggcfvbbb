package com.example.engine.normalization

import com.example.data.models.ContourPoint
import com.example.data.models.DrawnStroke
import com.example.data.models.GlyphMetric
import com.example.data.models.GlyphOutlineContour
import com.example.data.models.StrokePoint
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class NormalizedGlyphResult(
    val normalizedStrokes: List<DrawnStroke>,
    val contours: List<GlyphOutlineContour>,
    val metric: GlyphMetric
)

object GlyphNormalizer {

    private const val FONT_UPM = 1024
    private const val ASCENDER = 800
    private const val DESCENDER = -200
    private const val BASELINE_TARGET_Y = 0 // Baseline is 0 in TTF

    /**
     * Normalizes raw canvas strokes into TrueType font coordinate space (1024 UPM, Y up).
     */
    fun normalize(
        rawStrokes: List<DrawnStroke>,
        isAscender: Boolean = false,
        isDescender: Boolean = false,
        nominalCellHeight: Float = 600f // Typical canvas height
    ): NormalizedGlyphResult {
        if (rawStrokes.isEmpty() || rawStrokes.all { it.points.isEmpty() }) {
            return NormalizedGlyphResult(
                normalizedStrokes = emptyList(),
                contours = emptyList(),
                metric = GlyphMetric(
                    advanceWidth = 500,
                    leftSideBearing = 50,
                    rightSideBearing = 50,
                    xMin = 0,
                    yMin = 0,
                    xMax = 0,
                    yMax = 0
                )
            )
        }

        // 1. Calculate raw bounding box
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var maxY = Float.MIN_VALUE

        for (stroke in rawStrokes) {
            for (p in stroke.points) {
                if (p.x < minX) minX = p.x
                if (p.y < minY) minY = p.y
                if (p.x > maxX) maxX = p.x
                if (p.y > maxY) maxY = p.y
            }
        }

        val rawWidth = max(1f, maxX - minX)
        val rawHeight = max(1f, maxY - minY)

        // Target height in font units (UPM 1024)
        val targetHeight = if (isAscender && isDescender) 850f
        else if (isAscender) 750f
        else if (isDescender) 650f
        else 520f

        val scale = min(targetHeight / rawHeight, 900f / rawWidth)

        // Baseline on canvas is typically at ~70% of canvas height
        val canvasBaseline = minY + rawHeight * (if (isDescender) 0.55f else 0.85f)

        val leftSideBearing = 60
        val rightSideBearing = 60

        // 2. Transform stroke points into font space (Y inverted: in font coordinates, +Y is UP)
        val normalizedStrokes = mutableListOf<DrawnStroke>()
        val contours = mutableListOf<GlyphOutlineContour>()

        for (stroke in rawStrokes) {
            val normPoints = mutableListOf<StrokePoint>()
            for (p in stroke.points) {
                // Font X: shift by minX, scale, add LSB
                val fontX = (p.x - minX) * scale + leftSideBearing
                // Font Y: distance from baseline, scaled, positive upwards
                val fontY = (canvasBaseline - p.y) * scale
                normPoints.add(StrokePoint(fontX, fontY, p.pressure, p.timestamp))
            }
            if (normPoints.isNotEmpty()) {
                val normStroke = stroke.copy(
                    points = normPoints,
                    strokeWidth = max(8f, stroke.strokeWidth * scale * 0.45f)
                )
                normalizedStrokes.add(normStroke)

                // 3. Generate thick polygon contours for TTF glyf table
                val outline = strokeToPolygonOutline(normStroke)
                if (outline.points.size >= 3) {
                    contours.add(outline)
                }
            }
        }

        // Calculate final font metrics
        val glyphWidth = (rawWidth * scale).toInt()
        val totalAdvance = leftSideBearing + glyphWidth + rightSideBearing

        var fontMinX = Int.MAX_VALUE
        var fontMinY = Int.MAX_VALUE
        var fontMaxX = Int.MIN_VALUE
        var fontMaxY = Int.MIN_VALUE

        for (c in contours) {
            for (pt in c.points) {
                if (pt.x < fontMinX) fontMinX = pt.x
                if (pt.y < fontMinY) fontMinY = pt.y
                if (pt.x > fontMaxX) fontMaxX = pt.x
                if (pt.y > fontMaxY) fontMaxY = pt.y
            }
        }

        if (fontMinX > fontMaxX) {
            fontMinX = leftSideBearing
            fontMaxX = leftSideBearing + glyphWidth
            fontMinY = 0
            fontMaxY = (rawHeight * scale).toInt()
        }

        val metric = GlyphMetric(
            advanceWidth = totalAdvance,
            leftSideBearing = fontMinX,
            rightSideBearing = max(30, totalAdvance - fontMaxX),
            xMin = fontMinX,
            yMin = fontMinY,
            xMax = fontMaxX,
            yMax = fontMaxY
        )

        return NormalizedGlyphResult(
            normalizedStrokes = normalizedStrokes,
            contours = contours,
            metric = metric
        )
    }

    /**
     * Expands a centerline stroke with thickness into a closed polygon contour suitable for TrueType glyf tables.
     */
    private fun strokeToPolygonOutline(stroke: DrawnStroke): GlyphOutlineContour {
        val points = stroke.points
        if (points.isEmpty()) return GlyphOutlineContour()

        val halfWidth = max(4f, stroke.strokeWidth / 2f)

        if (points.size == 1) {
            // Draw small diamond/circle around single point (e.g. Persian dot / Nuqta)
            val p = points[0]
            val r = max(halfWidth * 1.5f, 18f)
            val list = listOf(
                ContourPoint((p.x).toInt(), (p.y + r).toInt(), true),
                ContourPoint((p.x + r).toInt(), (p.y).toInt(), true),
                ContourPoint((p.x).toInt(), (p.y - r).toInt(), true),
                ContourPoint((p.x - r).toInt(), (p.y).toInt(), true)
            )
            return GlyphOutlineContour(list)
        }

        val leftSide = mutableListOf<ContourPoint>()
        val rightSide = mutableListOf<ContourPoint>()

        for (i in points.indices) {
            val cur = points[i]
            val normalAngle = if (i == 0) {
                val next = points[1]
                atan2(next.y - cur.y, next.x - cur.x) + Math.PI.toFloat() / 2f
            } else if (i == points.size - 1) {
                val prev = points[i - 1]
                atan2(cur.y - prev.y, cur.x - prev.x) + Math.PI.toFloat() / 2f
            } else {
                val prev = points[i - 1]
                val next = points[i + 1]
                atan2(next.y - prev.y, next.x - prev.x) + Math.PI.toFloat() / 2f
            }

            val curWidth = halfWidth * (0.8f + cur.pressure * 0.4f)
            val dx = cos(normalAngle) * curWidth
            val dy = sin(normalAngle) * curWidth

            leftSide.add(ContourPoint((cur.x + dx).toInt(), (cur.y + dy).toInt(), true))
            rightSide.add(ContourPoint((cur.x - dx).toInt(), (cur.y - dy).toInt(), true))
        }

        // Combine left side forward, right side backward to form a clockwise closed contour
        val fullContour = mutableListOf<ContourPoint>()
        fullContour.addAll(leftSide)
        fullContour.addAll(rightSide.reversed())

        return GlyphOutlineContour(fullContour)
    }
}
