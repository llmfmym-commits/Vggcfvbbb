package com.example.engine.extraction

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

data class ExtractedGlyphCandidate(
    val id: Int,
    val bounds: Rect,
    val bitmap: Bitmap,
    var suggestedChar: String = "",
    var isConfirmed: Boolean = false
)

object PhotoGlyphExtractor {

    /**
     * Extracts individual handwritten glyph bounding boxes from a photo of a handwriting paper.
     */
    fun extractGlyphsFromImage(source: Bitmap): List<ExtractedGlyphCandidate> {
        val width = source.width
        val height = source.height

        // Downsample for analysis
        val maxDim = 800
        val scale = min(1f, maxDim.toFloat() / max(width, height))
        val scaledW = (width * scale).toInt()
        val scaledH = (height * scale).toInt()

        val working = Bitmap.createScaledBitmap(source, scaledW, scaledH, true)

        // 1. Convert to grayscale & compute Otsu threshold
        val pixels = IntArray(scaledW * scaledH)
        working.getPixels(pixels, 0, scaledW, 0, 0, scaledW, scaledH)

        val gray = IntArray(pixels.size)
        var sumLum = 0L
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val lum = (r * 77 + g * 150 + b * 29) shr 8
            gray[i] = lum
            sumLum += lum
        }
        val avgLum = (sumLum / pixels.size).toInt()
        val binarizeThreshold = max(60, avgLum - 25) // Slightly darker than average paper

        // Binary mask: true = ink, false = background
        val binary = BooleanArray(pixels.size)
        for (i in pixels.indices) {
            binary[i] = gray[i] < binarizeThreshold
        }

        // 2. Connected component bounding boxes (grid clustering)
        val visited = BooleanArray(pixels.size)
        val candidateBoxes = mutableListOf<Rect>()

        val minGlyphArea = (scaledW * scaledH) / 8000
        val maxGlyphArea = (scaledW * scaledH) / 15

        for (y in 5 until scaledH - 5 step 4) {
            for (x in 5 until scaledW - 5 step 4) {
                val idx = y * scaledW + x
                if (binary[idx] && !visited[idx]) {
                    // Flood fill bounds
                    var bMinX = x
                    var bMaxX = x
                    var bMinY = y
                    var bMaxY = y
                    var count = 0

                    val stack = IntArray(1024)
                    var top = 0
                    stack[top++] = (x shl 16) or y
                    visited[idx] = true

                    while (top > 0) {
                        val pos = stack[--top]
                        val px = pos shr 16
                        val py = pos and 0xFFFF
                        count++

                        if (px < bMinX) bMinX = px
                        if (px > bMaxX) bMaxX = px
                        if (py < bMinY) bMinY = py
                        if (py > bMaxY) bMaxY = py

                        val neighbors = intArrayOf(
                            px + 1, py,
                            px - 1, py,
                            px, py + 1,
                            px, py - 1
                        )

                        var k = 0
                        while (k < neighbors.size && top < 1020) {
                            val nx = neighbors[k]
                            val ny = neighbors[k + 1]
                            k += 2
                            if (nx in 0 until scaledW && ny in 0 until scaledH) {
                                val nIdx = ny * scaledW + nx
                                if (binary[nIdx] && !visited[nIdx]) {
                                    visited[nIdx] = true
                                    stack[top++] = (nx shl 16) or ny
                                }
                            }
                        }
                    }

                    val bw = bMaxX - bMinX
                    val bh = bMaxY - bMinY
                    val area = bw * bh

                    if (area in minGlyphArea..maxGlyphArea && bw > 12 && bh > 12) {
                        // Rescale back to source coordinates
                        val origBox = Rect(
                            max(0, (bMinX / scale).toInt() - 6),
                            max(0, (bMinY / scale).toInt() - 6),
                            min(width, (bMaxX / scale).toInt() + 6),
                            min(height, (bMaxY / scale).toInt() + 6)
                        )
                        candidateBoxes.add(origBox)
                    }
                }
            }
        }

        // 3. Crop candidate bitmaps with transparent/clean background
        val result = mutableListOf<ExtractedGlyphCandidate>()
        var idCounter = 1

        for (box in candidateBoxes.take(40)) {
            val cropW = box.width()
            val cropH = box.height()
            if (cropW > 10 && cropH > 10) {
                try {
                    val cropped = Bitmap.createBitmap(source, box.left, box.top, cropW, cropH)
                    val cleaned = removePaperBackground(cropped)
                    result.add(
                        ExtractedGlyphCandidate(
                            id = idCounter++,
                            bounds = box,
                            bitmap = cleaned,
                            suggestedChar = ""
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        return result
    }

    /**
     * Converts paper background to transparent PNG bitmap (Section 28).
     */
    fun removePaperBackground(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)

        var paperLum = 240
        var sampleCount = 0
        var sampleSum = 0
        // Sample corners to find paper tone
        val samplePoints = listOf(0, w - 1, (h - 1) * w, (h - 1) * w + w - 1)
        for (idx in samplePoints) {
            val p = pixels[idx]
            val lum = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
            sampleSum += lum
            sampleCount++
        }
        if (sampleCount > 0) {
            paperLum = sampleSum / sampleCount
        }

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val lum = (r + g + b) / 3

            if (lum >= paperLum - 30) {
                // Background paper -> transparent
                pixels[i] = 0x00000000
            } else {
                // Ink -> calculate natural alpha based on darkness
                val alpha = ((paperLum - lum).toFloat() / paperLum * 255f).toInt().coerceIn(100, 255)
                pixels[i] = Color.argb(alpha, r, g, b)
            }
        }

        output.setPixels(pixels, 0, w, 0, 0, w, h)
        return output
    }
}
