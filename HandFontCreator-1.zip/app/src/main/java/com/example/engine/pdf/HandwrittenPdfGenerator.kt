package com.example.engine.pdf

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.engine.shaping.PersianShaper
import java.io.File
import java.io.FileOutputStream
import kotlin.random.Random

data class PdfConfig(
    val title: String = "سند دست‌نویس من",
    val pageSize: PageSize = PageSize.A4,
    val template: PdfTemplate = PdfTemplate.LINED,
    val topMargin: Float = 60f,
    val bottomMargin: Float = 60f,
    val leftMargin: Float = 50f,
    val rightMargin: Float = 50f,
    val fontSize: Float = 18f,
    val lineSpacing: Float = 36f,
    val showPageNumbers: Boolean = true,
    val inkColorArgb: Int = 0xFF1E3A8A.toInt(), // Classic Royal Blue Pen
    val naturalness: Float = 0.5f
)

enum class PageSize(val title: String, val widthPt: Int, val heightPt: Int) {
    A4("A4 (595 x 842)", 595, 842),
    A5("A5 (420 x 595)", 420, 595),
    LETTER("Letter (612 x 792)", 612, 792)
}

enum class PdfTemplate(val title: String) {
    LINED("دفتر خط‌دار"),
    BLANK("کاغذ سفید"),
    GRID("شطرنجی"),
    EXAM("برگه امتحانی")
}

object HandwrittenPdfGenerator {

    /**
     * Generates a real multi-page PDF document on disk using Android's native PdfDocument.
     */
    fun generatePdf(
        context: Context,
        text: String,
        fontFile: File?,
        config: PdfConfig,
        outputFile: File
    ): File {
        val document = PdfDocument()

        val pageWidth = config.pageSize.widthPt
        val pageHeight = config.pageSize.heightPt

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = config.inkColorArgb
            textSize = config.fontSize
            if (fontFile != null && fontFile.exists()) {
                try {
                    typeface = Typeface.createFromFile(fontFile)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        val linePaint = Paint().apply {
            color = Color.argb(45, 100, 149, 237) // Subtle lined paper blue
            strokeWidth = 0.8f
        }

        val marginPaint = Paint().apply {
            color = Color.argb(60, 220, 38, 38) // Red margin guide
            strokeWidth = 1f
        }

        val textPaintPageNum = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GRAY
            textSize = 10f
            textAlign = Paint.Align.CENTER
        }

        // Layout text lines
        val availableWidth = pageWidth - (config.leftMargin + config.rightMargin)
        val rawParagraphs = text.split("\n")
        val wrappedLines = mutableListOf<String>()

        for (paragraph in rawParagraphs) {
            if (paragraph.isBlank()) {
                wrappedLines.add("")
                continue
            }
            val words = paragraph.split("\\s+".toRegex())
            var currentLine = StringBuilder()

            for (word in words) {
                val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
                val measured = paint.measureText(candidate)
                if (measured > availableWidth && currentLine.isNotEmpty()) {
                    wrappedLines.add(currentLine.toString())
                    currentLine = StringBuilder(word)
                } else {
                    currentLine = StringBuilder(candidate)
                }
            }
            if (currentLine.isNotEmpty()) {
                wrappedLines.add(currentLine.toString())
            }
        }

        val linesPerPage = ((pageHeight - config.topMargin - config.bottomMargin) / config.lineSpacing).toInt()
        val totalPages = maxOf(1, (wrappedLines.size + linesPerPage - 1) / linesPerPage)

        var lineIndex = 0

        for (pageNumber in 1..totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            val page = document.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            // 1. Draw Paper Background
            drawPaperBackground(canvas, pageWidth, pageHeight, config, linePaint, marginPaint)

            // 2. Draw Text Lines
            var currentY = config.topMargin + config.lineSpacing
            val rand = Random(42L + pageNumber * 100L)

            for (i in 0 until linesPerPage) {
                if (lineIndex >= wrappedLines.size) break
                val lineText = wrappedLines[lineIndex]
                lineIndex++

                if (lineText.isNotBlank()) {
                    // Check if RTL/Persian
                    val isRtl = lineText.any { PersianShaper.isPersianOrArabic(it) }

                    // Apply slight natural baseline wobble
                    val wobble = (rand.nextFloat() * 2f - 1f) * (1.5f * config.naturalness)
                    val drawY = currentY + wobble

                    if (isRtl) {
                        paint.textAlign = Paint.Align.RIGHT
                        val drawX = pageWidth - config.rightMargin + (rand.nextFloat() * 2f - 1f) * config.naturalness
                        canvas.drawText(lineText, drawX, drawY, paint)
                    } else {
                        paint.textAlign = Paint.Align.LEFT
                        val drawX = config.leftMargin + (rand.nextFloat() * 2f - 1f) * config.naturalness
                        canvas.drawText(lineText, drawX, drawY, paint)
                    }
                }
                currentY += config.lineSpacing
            }

            // 3. Draw Page Number
            if (config.showPageNumbers) {
                canvas.drawText(
                    "- $pageNumber -",
                    pageWidth / 2f,
                    pageHeight - config.bottomMargin / 2f,
                    textPaintPageNum
                )
            }

            document.finishPage(page)
        }

        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { fos ->
            document.writeTo(fos)
        }
        document.close()

        return outputFile
    }

    private fun drawPaperBackground(
        canvas: Canvas,
        width: Int,
        height: Int,
        config: PdfConfig,
        linePaint: Paint,
        marginPaint: Paint
    ) {
        // Soft paper tint
        canvas.drawColor(Color.rgb(253, 252, 248))

        when (config.template) {
            PdfTemplate.LINED -> {
                // Horizontal ruled lines
                var y = config.topMargin + config.lineSpacing
                while (y < height - config.bottomMargin) {
                    canvas.drawLine(config.leftMargin, y, width - config.rightMargin, y, linePaint)
                    y += config.lineSpacing
                }
                // Red margin line
                canvas.drawLine(config.leftMargin - 15f, config.topMargin, config.leftMargin - 15f, height - config.bottomMargin, marginPaint)
            }
            PdfTemplate.GRID -> {
                val gridStep = 20f
                var x = config.leftMargin
                while (x < width - config.rightMargin) {
                    canvas.drawLine(x, config.topMargin, x, height - config.bottomMargin, linePaint)
                    x += gridStep
                }
                var y = config.topMargin
                while (y < height - config.bottomMargin) {
                    canvas.drawLine(config.leftMargin, y, width - config.rightMargin, y, linePaint)
                    y += gridStep
                }
            }
            PdfTemplate.EXAM -> {
                // Header box
                val headerPaint = Paint().apply {
                    color = Color.DKGRAY
                    strokeWidth = 1.2f
                    style = Paint.Style.STROKE
                }
                canvas.drawRect(config.leftMargin, config.topMargin - 30f, width - config.rightMargin, config.topMargin + 20f, headerPaint)
                var y = config.topMargin + config.lineSpacing + 10f
                while (y < height - config.bottomMargin) {
                    canvas.drawLine(config.leftMargin, y, width - config.rightMargin, y, linePaint)
                    y += config.lineSpacing
                }
            }
            PdfTemplate.BLANK -> {
                // Blank white paper: no ruling lines
            }
        }
    }
}
