package com.example.ui.navigation

sealed class ScreenRoute(val route: String, val title: String, val farsiTitle: String) {
    object Home : ScreenRoute("home", "Home", "خانه")
    object GlyphCollection : ScreenRoute("glyph_collection", "Collect Glyphs", "جمع‌آوری حروف")
    object FontPreview : ScreenRoute("font_preview", "Font Preview", "پیش‌نمایش فونت")
    object FontInspector : ScreenRoute("font_inspector", "Font Inspector", "مشخصات فنی فونت")
    object HandwritingTest : ScreenRoute("handwriting_test", "Test Handwriting", "آزمایش دستخط")
    object PaperWriter : ScreenRoute("paper_writer", "Write on Paper", "نوشتن روی دفتر")
    object PdfMaker : ScreenRoute("pdf_maker", "PDF Studio", "ساخت PDF دستنویس")
    object SignatureMaker : ScreenRoute("signature_maker", "Signature Maker", "امضای من")
    object FreeCanvas : ScreenRoute("free_canvas", "Free Canvas", "صفحه آزاد")
    object PhotoExtraction : ScreenRoute("photo_extraction", "Photo Extract", "استخراج از عکس")
    object MyProjects : ScreenRoute("my_projects", "My Fonts", "فونت‌های من")
    object Settings : ScreenRoute("settings", "Settings", "تنظیمات")
}
