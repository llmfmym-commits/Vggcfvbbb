package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.FontProjectEntity
import com.example.data.database.GlyphEntity
import com.example.data.database.ProjectVersionEntity
import com.example.data.database.SignatureEntity
import com.example.data.models.DrawnStroke
import com.example.data.models.HandwritingStats
import com.example.data.models.Language
import com.example.data.models.PenType
import com.example.data.models.PencilHardness
import com.example.data.models.StylePreset
import com.example.data.models.ToolType
import com.example.data.repository.FontRepository
import com.example.data.serialization.ProjectFileHandler
import com.example.data.serialization.StrokeConverter
import com.example.engine.catalog.GlyphCatalog
import com.example.engine.catalog.GlyphRequirement
import com.example.engine.pdf.HandwrittenPdfGenerator
import com.example.engine.pdf.PdfConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class FontStudioViewModel(application: Application) : AndroidViewModel(application) {

    val repository = FontRepository(application)

    val allProjects: StateFlow<List<FontProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSignatures: StateFlow<List<SignatureEntity>> = repository.allSignatures
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentProject = MutableStateFlow<FontProjectEntity?>(null)
    val currentProject: StateFlow<FontProjectEntity?> = _currentProject.asStateFlow()

    private val _projectGlyphs = MutableStateFlow<List<GlyphEntity>>(emptyList())
    val projectGlyphs: StateFlow<List<GlyphEntity>> = _projectGlyphs.asStateFlow()

    private val _projectVersions = MutableStateFlow<List<ProjectVersionEntity>>(emptyList())
    val projectVersions: StateFlow<List<ProjectVersionEntity>> = _projectVersions.asStateFlow()

    // Wizard step state
    private val _wizardRequirements = MutableStateFlow<List<GlyphRequirement>>(emptyList())
    val wizardRequirements: StateFlow<List<GlyphRequirement>> = _wizardRequirements.asStateFlow()

    private val _currentWizardIndex = MutableStateFlow(0)
    val currentWizardIndex: StateFlow<Int> = _currentWizardIndex.asStateFlow()

    // Canvas drawing states
    private val _currentStrokes = MutableStateFlow<List<DrawnStroke>>(emptyList())
    val currentStrokes: StateFlow<List<DrawnStroke>> = _currentStrokes.asStateFlow()

    private val _undoStack = MutableStateFlow<List<List<DrawnStroke>>>(emptyList())
    private val _redoStack = MutableStateFlow<List<List<DrawnStroke>>>(emptyList())
    val canUndo: StateFlow<Boolean> = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = MutableStateFlow(false)

    // Drawing tool settings
    var currentTool = MutableStateFlow(ToolType.PENCIL)
    var currentColorArgb = MutableStateFlow(0xFF2F3237L)
    var currentStrokeWidth = MutableStateFlow(14f)
    var pencilHardness = MutableStateFlow(PencilHardness.B2)
    var penType = MutableStateFlow(PenType.BALLPOINT)

    // Exported TTF and PDF files
    private val _exportedTtfFile = MutableStateFlow<File?>(null)
    val exportedTtfFile: StateFlow<File?> = _exportedTtfFile.asStateFlow()

    private val _exportedPdfFile = MutableStateFlow<File?>(null)
    val exportedPdfFile: StateFlow<File?> = _exportedPdfFile.asStateFlow()

    private val _handwritingStats = MutableStateFlow<HandwritingStats?>(null)
    val handwritingStats: StateFlow<HandwritingStats?> = _handwritingStats.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        viewModelScope.launch {
            allProjects.collect { list ->
                if (_currentProject.value == null && list.isNotEmpty()) {
                    selectProject(list.first().id)
                } else if (list.isEmpty()) {
                    // Create default first project: "دستخط من"
                    val defaultId = repository.createProject(
                        name = "دستخط من",
                        author = "من",
                        language = Language.PERSIAN,
                        description = "اولین استودیوی ساخت دستخط شخصی"
                    )
                    selectProject(defaultId)
                }
            }
        }
    }

    fun selectProject(projectId: Long) {
        viewModelScope.launch {
            val proj = repository.getProject(projectId)
            _currentProject.value = proj
            if (proj != null) {
                val lang = try { Language.valueOf(proj.language) } catch (_: Exception) { Language.PERSIAN }
                val reqs = GlyphCatalog.getRequirementsForLanguage(lang)
                _wizardRequirements.value = reqs

                repository.getGlyphsFlow(projectId).collect { glyphs ->
                    _projectGlyphs.value = glyphs
                    loadCurrentWizardGlyphStrokes()
                    refreshStats(projectId)
                }
            }
        }
        viewModelScope.launch {
            repository.getVersionsFlow(projectId).collect { versions ->
                _projectVersions.value = versions
            }
        }
    }

    fun createNewProject(name: String, author: String, language: Language, description: String = "") {
        viewModelScope.launch {
            val newId = repository.createProject(name, author, language, description)
            selectProject(newId)
            _statusMessage.value = "پروژه جدید ساخته شد"
        }
    }

    fun updateProjectSettings(
        naturalness: Float,
        preset: StylePreset,
        strokeWidth: Float
    ) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            val updated = proj.copy(
                naturalizationLevel = naturalness,
                stylePreset = preset.name,
                defaultStrokeWidth = strokeWidth
            )
            repository.updateProject(updated)
            _currentProject.value = updated
        }
    }

    fun updateProjectMetadata(name: String, author: String, version: String, description: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            val updated = proj.copy(
                name = name,
                author = author,
                version = version,
                description = description
            )
            repository.updateProject(updated)
            _currentProject.value = updated
            _statusMessage.value = "مشخصات فونت بروزرسانی شد"
        }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            val remaining = allProjects.value.filter { it.id != projectId }
            if (remaining.isNotEmpty()) {
                selectProject(remaining.first().id)
            } else {
                _currentProject.value = null
            }
        }
    }

    fun setWizardIndex(index: Int) {
        val reqs = _wizardRequirements.value
        if (index in reqs.indices) {
            _currentWizardIndex.value = index
            loadCurrentWizardGlyphStrokes()
        }
    }

    fun nextWizardGlyph() {
        val nextIdx = _currentWizardIndex.value + 1
        if (nextIdx < _wizardRequirements.value.size) {
            _currentWizardIndex.value = nextIdx
            loadCurrentWizardGlyphStrokes()
        }
    }

    fun previousWizardGlyph() {
        val prevIdx = _currentWizardIndex.value - 1
        if (prevIdx >= 0) {
            _currentWizardIndex.value = prevIdx
            loadCurrentWizardGlyphStrokes()
        }
    }

    private fun loadCurrentWizardGlyphStrokes() {
        val req = currentRequirement() ?: return
        val existing = _projectGlyphs.value.find {
            it.glyphName == req.name && it.formType == req.form.name
        }
        val strokes = if (existing != null) StrokeConverter.jsonToStrokes(existing.strokesJson) else emptyList()
        _currentStrokes.value = strokes
        _undoStack.value = emptyList()
        _redoStack.value = emptyList()
        updateUndoRedoStates()
    }

    fun currentRequirement(): GlyphRequirement? {
        val list = _wizardRequirements.value
        val idx = _currentWizardIndex.value
        return if (idx in list.indices) list[idx] else null
    }

    fun addStroke(stroke: DrawnStroke) {
        val prev = _currentStrokes.value
        _undoStack.value = _undoStack.value + listOf(prev)
        _redoStack.value = emptyList()
        _currentStrokes.value = prev + stroke
        updateUndoRedoStates()
    }

    fun undo() {
        val stack = _undoStack.value
        if (stack.isNotEmpty()) {
            val lastState = stack.last()
            _redoStack.value = _redoStack.value + listOf(_currentStrokes.value)
            _undoStack.value = stack.dropLast(1)
            _currentStrokes.value = lastState
            updateUndoRedoStates()
        }
    }

    fun redo() {
        val stack = _redoStack.value
        if (stack.isNotEmpty()) {
            val nextState = stack.last()
            _undoStack.value = _undoStack.value + listOf(_currentStrokes.value)
            _redoStack.value = stack.dropLast(1)
            _currentStrokes.value = nextState
            updateUndoRedoStates()
        }
    }

    fun clearCanvas() {
        val prev = _currentStrokes.value
        if (prev.isNotEmpty()) {
            _undoStack.value = _undoStack.value + listOf(prev)
            _redoStack.value = emptyList()
            _currentStrokes.value = emptyList()
            updateUndoRedoStates()
        }
    }

    private fun updateUndoRedoStates() {
        (canUndo as MutableStateFlow).value = _undoStack.value.isNotEmpty()
        (canRedo as MutableStateFlow).value = _redoStack.value.isNotEmpty()
    }

    fun confirmCurrentGlyph() {
        val proj = _currentProject.value ?: return
        val req = currentRequirement() ?: return

        viewModelScope.launch {
            repository.saveGlyphStrokes(
                projectId = proj.id,
                glyphName = req.name,
                formType = req.form.name,
                sampleIndex = 1,
                charCode = req.charCode,
                strokes = _currentStrokes.value,
                isNormalized = true
            )
            _statusMessage.value = "حرف «${req.name}» ذخیره شد"
            nextWizardGlyph()
        }
    }

    fun generateTtf() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            try {
                val file = repository.generateAndExportTtf(proj.id)
                _exportedTtfFile.value = file
                _statusMessage.value = "فونت واقعی TTF ساخته شد: ${file.name}"
            } catch (e: Exception) {
                e.printStackTrace()
                _statusMessage.value = "خطا در ساخت فونت: ${e.localizedMessage}"
            }
        }
    }

    fun generatePdf(text: String, config: PdfConfig) {
        viewModelScope.launch {
            try {
                val dir = File(getApplication<Application>().filesDir, "generated_pdfs")
                dir.mkdirs()
                val targetFile = File(dir, "HandFont_Document_${System.currentTimeMillis()}.pdf")
                val ttfFile = _exportedTtfFile.value
                val result = HandwrittenPdfGenerator.generatePdf(
                    context = getApplication(),
                    text = text,
                    fontFile = ttfFile,
                    config = config,
                    outputFile = targetFile
                )
                _exportedPdfFile.value = result
                _statusMessage.value = "فایل PDF دست‌نویس آماده شد: ${result.name}"
            } catch (e: Exception) {
                e.printStackTrace()
                _statusMessage.value = "خطا در تولید PDF: ${e.localizedMessage}"
            }
        }
    }

    fun saveSignature(title: String, bitmap: Bitmap) {
        viewModelScope.launch {
            repository.saveSignature(title, bitmap)
            _statusMessage.value = "امضا با پس‌زمینه شفاف ذخیره شد"
        }
    }

    fun deleteSignature(sig: SignatureEntity) {
        viewModelScope.launch {
            repository.deleteSignature(sig)
        }
    }

    fun createVersionSnapshot(note: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch {
            repository.createVersionSnapshot(proj.id, note)
            _statusMessage.value = "نسخه جدید با موفقیت ثبت شد"
        }
    }

    fun restoreVersion(version: ProjectVersionEntity) {
        viewModelScope.launch {
            repository.restoreVersion(version)
            selectProject(version.projectId)
            _statusMessage.value = "نسخه ${version.versionName} بازگردانی شد"
        }
    }

    fun exportProjectHfp(): String? {
        val proj = _currentProject.value ?: return null
        val glyphs = _projectGlyphs.value
        return ProjectFileHandler.exportToHfp(proj, glyphs)
    }

    fun importProjectHfp(jsonContent: String) {
        viewModelScope.launch {
            try {
                val data = ProjectFileHandler.importFromHfp(jsonContent)
                val newId = repository.createProject(
                    name = data.project.name + " (Imported)",
                    author = data.project.author,
                    language = try { Language.valueOf(data.project.language) } catch (_: Exception) { Language.PERSIAN },
                    description = data.project.description
                )
                for (g in data.glyphs) {
                    val strokes = StrokeConverter.jsonToStrokes(g.strokesJson)
                    repository.saveGlyphStrokes(
                        projectId = newId,
                        glyphName = g.glyphName,
                        formType = g.formType,
                        sampleIndex = g.sampleIndex,
                        charCode = g.charCode,
                        strokes = strokes,
                        isNormalized = g.isNormalized
                    )
                }
                selectProject(newId)
                _statusMessage.value = "پروژه HFP با موفقیت ایمپورت شد"
            } catch (e: Exception) {
                e.printStackTrace()
                _statusMessage.value = "خطا در ایمپورت پروژه"
            }
        }
    }

    fun refreshStats(projectId: Long) {
        viewModelScope.launch {
            _handwritingStats.value = repository.computeHandwritingStats(projectId)
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }
}
