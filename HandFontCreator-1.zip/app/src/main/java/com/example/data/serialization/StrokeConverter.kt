package com.example.data.serialization

import com.example.data.database.FontProjectEntity
import com.example.data.database.GlyphEntity
import com.example.data.models.DrawnStroke
import com.example.data.models.PenType
import com.example.data.models.PencilHardness
import com.example.data.models.StrokePoint
import com.example.data.models.ToolType
import org.json.JSONArray
import org.json.JSONObject

object StrokeConverter {

    fun strokesToJson(strokes: List<DrawnStroke>): String {
        val root = JSONArray()
        for (stroke in strokes) {
            val strokeObj = JSONObject()
            strokeObj.put("tool", stroke.tool.name)
            strokeObj.put("color", stroke.colorArgb)
            strokeObj.put("width", stroke.strokeWidth.toDouble())
            strokeObj.put("hardness", stroke.pencilHardness.name)
            strokeObj.put("penType", stroke.penType.name)

            val pointsArray = JSONArray()
            for (p in stroke.points) {
                val pObj = JSONObject()
                pObj.put("x", p.x.toDouble())
                pObj.put("y", p.y.toDouble())
                pObj.put("p", p.pressure.toDouble())
                pObj.put("t", p.timestamp)
                pointsArray.put(pObj)
            }
            strokeObj.put("points", pointsArray)
            root.put(strokeObj)
        }
        return root.toString()
    }

    fun jsonToStrokes(json: String?): List<DrawnStroke> {
        if (json.isNullOrBlank()) return emptyList()
        val result = mutableListOf<DrawnStroke>()
        try {
            val root = JSONArray(json)
            for (i in 0 until root.length()) {
                val strokeObj = root.getJSONObject(i)
                val toolName = strokeObj.optString("tool", ToolType.PENCIL.name)
                val tool = try { ToolType.valueOf(toolName) } catch (_: Exception) { ToolType.PENCIL }
                val color = strokeObj.optLong("color", 0xFF2A2A2AL)
                val width = strokeObj.optDouble("width", 12.0).toFloat()
                val hardnessName = strokeObj.optString("hardness", PencilHardness.B2.name)
                val hardness = try { PencilHardness.valueOf(hardnessName) } catch (_: Exception) { PencilHardness.B2 }
                val penTypeName = strokeObj.optString("penType", PenType.BALLPOINT.name)
                val penType = try { PenType.valueOf(penTypeName) } catch (_: Exception) { PenType.BALLPOINT }

                val pointsArray = strokeObj.optJSONArray("points") ?: JSONArray()
                val points = mutableListOf<StrokePoint>()
                for (j in 0 until pointsArray.length()) {
                    val pObj = pointsArray.getJSONObject(j)
                    val x = pObj.getDouble("x").toFloat()
                    val y = pObj.getDouble("y").toFloat()
                    val p = pObj.optDouble("p", 0.5).toFloat()
                    val t = pObj.optLong("t", System.currentTimeMillis())
                    points.add(StrokePoint(x, y, p, t))
                }
                result.add(DrawnStroke(points, tool, color, width, hardness, penType))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}

object ProjectFileHandler {

    /**
     * Creates a complete .hfp (HandFont Project) package string
     */
    fun exportToHfp(project: FontProjectEntity, glyphs: List<GlyphEntity>): String {
        val root = JSONObject()
        root.put("format", "HandFontProject")
        root.put("schemaVersion", 1)

        val projObj = JSONObject()
        projObj.put("id", project.id)
        projObj.put("name", project.name)
        projObj.put("familyName", project.familyName)
        projObj.put("author", project.author)
        projObj.put("version", project.version)
        projObj.put("description", project.description)
        projObj.put("language", project.language)
        projObj.put("naturalizationLevel", project.naturalizationLevel.toDouble())
        projObj.put("stylePreset", project.stylePreset)
        projObj.put("upm", project.upm)
        projObj.put("ascender", project.ascender)
        projObj.put("descender", project.descender)
        projObj.put("defaultStrokeWidth", project.defaultStrokeWidth.toDouble())
        projObj.put("pencilHardness", project.pencilHardness)
        projObj.put("createdAt", project.createdAt)
        projObj.put("updatedAt", project.updatedAt)
        root.put("project", projObj)

        val glyphsArray = JSONArray()
        for (g in glyphs) {
            val gObj = JSONObject()
            gObj.put("charCode", g.charCode)
            gObj.put("glyphName", g.glyphName)
            gObj.put("formType", g.formType)
            gObj.put("sampleIndex", g.sampleIndex)
            gObj.put("strokesJson", g.strokesJson)
            gObj.put("advanceWidth", g.advanceWidth)
            gObj.put("leftSideBearing", g.leftSideBearing)
            gObj.put("rightSideBearing", g.rightSideBearing)
            gObj.put("minX", g.minX.toDouble())
            gObj.put("minY", g.minY.toDouble())
            gObj.put("maxX", g.maxX.toDouble())
            gObj.put("maxY", g.maxY.toDouble())
            gObj.put("isNormalized", g.isNormalized)
            glyphsArray.put(gObj)
        }
        root.put("glyphs", glyphsArray)

        return root.toString(2)
    }

    data class ImportedProjectData(
        val project: FontProjectEntity,
        val glyphs: List<GlyphEntity>
    )

    fun importFromHfp(jsonContent: String): ImportedProjectData {
        val root = JSONObject(jsonContent)
        val projObj = root.getJSONObject("project")
        val project = FontProjectEntity(
            id = 0, // Generate new ID on import
            name = projObj.optString("name", "Imported Font"),
            familyName = projObj.optString("familyName", "HandFont"),
            author = projObj.optString("author", "Unknown"),
            version = projObj.optString("version", "1.0"),
            description = projObj.optString("description", ""),
            language = projObj.optString("language", "PERSIAN"),
            naturalizationLevel = projObj.optDouble("naturalizationLevel", 0.5).toFloat(),
            stylePreset = projObj.optString("stylePreset", "NATURAL"),
            upm = projObj.optInt("upm", 1024),
            ascender = projObj.optInt("ascender", 800),
            descender = projObj.optInt("descender", -200),
            defaultStrokeWidth = projObj.optDouble("defaultStrokeWidth", 14.0).toFloat(),
            pencilHardness = projObj.optString("pencilHardness", "B2"),
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        val glyphsArray = root.optJSONArray("glyphs") ?: JSONArray()
        val glyphs = mutableListOf<GlyphEntity>()
        for (i in 0 until glyphsArray.length()) {
            val gObj = glyphsArray.getJSONObject(i)
            glyphs.add(
                GlyphEntity(
                    id = 0,
                    projectId = 0,
                    charCode = gObj.getInt("charCode"),
                    glyphName = gObj.getString("glyphName"),
                    formType = gObj.getString("formType"),
                    sampleIndex = gObj.optInt("sampleIndex", 1),
                    strokesJson = gObj.getString("strokesJson"),
                    advanceWidth = gObj.optInt("advanceWidth", 600),
                    leftSideBearing = gObj.optInt("leftSideBearing", 50),
                    rightSideBearing = gObj.optInt("rightSideBearing", 50),
                    minX = gObj.optDouble("minX", 0.0).toFloat(),
                    minY = gObj.optDouble("minY", 0.0).toFloat(),
                    maxX = gObj.optDouble("maxX", 0.0).toFloat(),
                    maxY = gObj.optDouble("maxY", 0.0).toFloat(),
                    isNormalized = gObj.optBoolean("isNormalized", true)
                )
            )
        }
        return ImportedProjectData(project, glyphs)
    }
}
