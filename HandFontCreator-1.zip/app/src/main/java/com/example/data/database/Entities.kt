package com.example.data.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.models.Language
import com.example.data.models.PencilHardness
import com.example.data.models.StylePreset

@Entity(tableName = "font_projects")
data class FontProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val familyName: String = name,
    val author: String = "User",
    val version: String = "1.0",
    val description: String = "",
    val language: String = Language.PERSIAN.name,
    val naturalizationLevel: Float = 0.5f,
    val stylePreset: String = StylePreset.NATURAL.name,
    val upm: Int = 1024,
    val ascender: Int = 800,
    val descender: Int = -200,
    val defaultStrokeWidth: Float = 14f,
    val pencilHardness: String = PencilHardness.B2.name,
    val isFavorite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "font_glyphs",
    indices = [
        Index(value = ["projectId", "glyphName", "formType", "sampleIndex"], unique = true),
        Index(value = ["projectId"])
    ]
)
data class GlyphEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val charCode: Int,
    val glyphName: String,
    val formType: String,
    val sampleIndex: Int = 1,
    val strokesJson: String,
    val advanceWidth: Int = 600,
    val leftSideBearing: Int = 50,
    val rightSideBearing: Int = 50,
    val minX: Float = 0f,
    val minY: Float = 0f,
    val maxX: Float = 0f,
    val maxY: Float = 0f,
    val isNormalized: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "signatures")
data class SignatureEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val width: Int,
    val height: Int,
    val pngBase64: String
)

@Entity(tableName = "project_versions")
data class ProjectVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val versionName: String,
    val snapshotJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val note: String = ""
)
