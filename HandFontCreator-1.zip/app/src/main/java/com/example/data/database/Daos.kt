package com.example.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM font_projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<FontProjectEntity>>

    @Query("SELECT * FROM font_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): FontProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: FontProjectEntity): Long

    @Update
    suspend fun updateProject(project: FontProjectEntity)

    @Delete
    suspend fun deleteProject(project: FontProjectEntity)

    @Query("DELETE FROM font_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)
}

@Dao
interface GlyphDao {
    @Query("SELECT * FROM font_glyphs WHERE projectId = :projectId ORDER BY charCode ASC, formType ASC, sampleIndex ASC")
    fun getGlyphsByProject(projectId: Long): Flow<List<GlyphEntity>>

    @Query("SELECT * FROM font_glyphs WHERE projectId = :projectId ORDER BY charCode ASC, formType ASC, sampleIndex ASC")
    suspend fun getGlyphsByProjectOnce(projectId: Long): List<GlyphEntity>

    @Query("SELECT * FROM font_glyphs WHERE projectId = :projectId AND glyphName = :glyphName AND formType = :formType AND sampleIndex = :sampleIndex LIMIT 1")
    suspend fun getGlyph(projectId: Long, glyphName: String, formType: String, sampleIndex: Int): GlyphEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGlyph(glyph: GlyphEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(glyphs: List<GlyphEntity>)

    @Update
    suspend fun updateGlyph(glyph: GlyphEntity)

    @Delete
    suspend fun deleteGlyph(glyph: GlyphEntity)

    @Query("DELETE FROM font_glyphs WHERE projectId = :projectId")
    suspend fun deleteAllByProject(projectId: Long)
}

@Dao
interface SignatureDao {
    @Query("SELECT * FROM signatures ORDER BY createdAt DESC")
    fun getAllSignatures(): Flow<List<SignatureEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSignature(sig: SignatureEntity): Long

    @Delete
    suspend fun deleteSignature(sig: SignatureEntity)
}

@Dao
interface VersionDao {
    @Query("SELECT * FROM project_versions WHERE projectId = :projectId ORDER BY createdAt DESC")
    fun getVersionsByProject(projectId: Long): Flow<List<ProjectVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: ProjectVersionEntity): Long

    @Delete
    suspend fun deleteVersion(version: ProjectVersionEntity)
}
